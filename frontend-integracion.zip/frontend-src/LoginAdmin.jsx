import { useState } from "react";
import { useAuth } from "./context/AuthContext";
import { Lock } from "lucide-react";

const FONT_IMPORT = `@import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Inter:wght@400;500;600;700&display=swap');`;

export default function LoginAdmin({ onIngreso }) {
  const { iniciarSesion } = useAuth();
  const [correo, setCorreo] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [cargando, setCargando] = useState(false);

  async function manejarIngreso() {
    setError("");
    setCargando(true);
    try {
      await iniciarSesion(correo, password);
      onIngreso?.();
    } catch (err) {
      setError(err.message);
    } finally {
      setCargando(false);
    }
  }

  return (
    <div
      className="min-h-screen bg-[#0E0B1A] flex items-center justify-center px-6"
      style={{ fontFamily: "'Inter', sans-serif" }}
    >
      <style>{FONT_IMPORT}</style>
      <div className="w-full max-w-sm">
        <div
          className="text-white text-2xl tracking-wide mb-8 text-center"
          style={{ fontFamily: "'Bebas Neue', sans-serif" }}
        >
          jalemos<span className="text-[#FF3D71]">.com</span>
          <div
            className="text-[11px] text-[#6E6785] tracking-wider mt-1"
            style={{ fontFamily: "'Inter', sans-serif" }}
          >
            Panel administrativo
          </div>
        </div>

        <div className="bg-white/5 border border-white/10 p-6 space-y-4">
          <div>
            <label className="text-[#9A93B3] text-xs block mb-1">Correo</label>
            <input
              type="email"
              value={correo}
              onChange={(e) => setCorreo(e.target.value)}
              className="w-full bg-white/5 border border-white/10 text-white px-3 py-2.5 outline-none focus:border-[#FF3D71] transition-colors"
            />
          </div>
          <div>
            <label className="text-[#9A93B3] text-xs block mb-1">Contraseña</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && manejarIngreso()}
              className="w-full bg-white/5 border border-white/10 text-white px-3 py-2.5 outline-none focus:border-[#FF3D71] transition-colors"
            />
          </div>

          {error && <p className="text-[#FF3D71] text-xs">{error}</p>}

          <button
            onClick={manejarIngreso}
            disabled={cargando}
            className="w-full flex items-center justify-center gap-2 bg-[#FF3D71] text-white font-semibold py-2.5 hover:bg-[#e6285d] transition-colors disabled:opacity-50"
          >
            <Lock size={15} />
            {cargando ? "Ingresando..." : "Ingresar"}
          </button>
        </div>
      </div>
    </div>
  );
}
