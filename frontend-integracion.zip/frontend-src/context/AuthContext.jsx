import { createContext, useContext, useState } from "react";
import { login as loginApi } from "../services/api";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [usuario, setUsuario] = useState(() => {
    const guardado = localStorage.getItem("jalemos_usuario");
    return guardado ? JSON.parse(guardado) : null;
  });

  async function iniciarSesion(correo, password) {
    const { token, usuario: datosUsuario } = await loginApi(correo, password);
    localStorage.setItem("jalemos_token", token);
    localStorage.setItem("jalemos_usuario", JSON.stringify(datosUsuario));
    setUsuario(datosUsuario);
  }

  function cerrarSesion() {
    localStorage.removeItem("jalemos_token");
    localStorage.removeItem("jalemos_usuario");
    setUsuario(null);
  }

  return (
    <AuthContext.Provider value={{ usuario, iniciarSesion, cerrarSesion }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const contexto = useContext(AuthContext);
  if (!contexto) throw new Error("useAuth debe usarse dentro de <AuthProvider>");
  return contexto;
}
