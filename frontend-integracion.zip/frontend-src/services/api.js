const API_URL = import.meta.env.VITE_API_URL || "http://localhost:4000/api";

// Lee el token guardado tras el login del admin.
function obtenerToken() {
  return localStorage.getItem("jalemos_token");
}

// Envoltorio base: arma la URL, agrega el token si existe,
// y lanza un error legible si la respuesta no fue exitosa.
async function peticion(ruta, opciones = {}) {
  const headers = { ...(opciones.headers || {}) };
  const token = obtenerToken();

  if (token) headers["Authorization"] = `Bearer ${token}`;
  if (!(opciones.body instanceof FormData)) {
    headers["Content-Type"] = "application/json";
  }

  const respuesta = await fetch(`${API_URL}${ruta}`, { ...opciones, headers });
  const data = await respuesta.json().catch(() => ({}));

  if (!respuesta.ok) {
    throw new Error(data.error || "Ocurrió un error inesperado");
  }

  return data;
}

// --- Autenticación ---
export function login(correo, password) {
  return peticion("/auth/login", {
    method: "POST",
    body: JSON.stringify({ correo, password }),
  });
}

// --- Eventos ---
export function obtenerEventos() {
  return peticion("/eventos");
}

export function obtenerEvento(id) {
  return peticion(`/eventos/${id}`);
}

export function crearEvento(formData) {
  // formData debe incluir: titulo, descripcion, fecha, lugar, precio, fotos[]
  return peticion("/eventos", { method: "POST", body: formData });
}

// --- Transacciones ---
export function crearTransaccion(formData) {
  // formData debe incluir: eventoId, correoComprador, cantidadTickets,
  // metodoPago, y "comprobante" (archivo) o "tokenPago" según el método
  return peticion("/transacciones", { method: "POST", body: formData });
}

export function listarTransacciones() {
  return peticion("/transacciones");
}

export function aprobarTransaccion(id) {
  return peticion(`/transacciones/${id}/aprobar`, { method: "PATCH" });
}

export function rechazarTransaccion(id) {
  return peticion(`/transacciones/${id}/rechazar`, { method: "PATCH" });
}
