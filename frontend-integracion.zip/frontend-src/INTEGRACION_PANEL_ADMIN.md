# Cómo conectar panel_admin.jsx al backend real

## 1. En `VistaCrearEvento`, reemplaza el botón "Publicar evento"

```jsx
import { useState } from "react";
import { crearEvento } from "./services/api";

function VistaCrearEvento() {
  const [form, setForm] = useState({
    titulo: "", descripcion: "", fecha: "", lugar: "", precio: "",
  });
  const [fotos, setFotos] = useState([]);
  const [enviando, setEnviando] = useState(false);
  const [mensaje, setMensaje] = useState("");

  async function publicarEvento() {
    setEnviando(true);
    setMensaje("");
    try {
      const formData = new FormData();
      Object.entries(form).forEach(([clave, valor]) => formData.append(clave, valor));
      fotos.forEach((archivo) => formData.append("fotos", archivo));

      await crearEvento(formData);
      setMensaje("Evento publicado correctamente.");
      setForm({ titulo: "", descripcion: "", fecha: "", lugar: "", precio: "" });
      setFotos([]);
    } catch (error) {
      setMensaje(error.message);
    } finally {
      setEnviando(false);
    }
  }

  // en el <input type="file" ...> de fotos:
  // onChange={(e) => setFotos(Array.from(e.target.files || []))}

  // cada <input> de texto ahora lleva:
  // value={form.titulo} onChange={(e) => setForm({ ...form, titulo: e.target.value })}
  // (y así con descripcion, fecha, lugar, precio)

  // el botón final:
  // <button onClick={publicarEvento} disabled={enviando}>
  //   {enviando ? "Publicando..." : "Publicar evento"}
  // </button>
}
```

## 2. En `VistaTransacciones`, carga los datos reales al abrir la vista

```jsx
import { useEffect, useState } from "react";
import { listarTransacciones, aprobarTransaccion, rechazarTransaccion } from "./services/api";

function VistaTransacciones() {
  const [transacciones, setTransacciones] = useState([]);
  const [filtro, setFiltro] = useState("todos");

  useEffect(() => {
    cargar();
  }, []);

  async function cargar() {
    const data = await listarTransacciones();
    setTransacciones(data);
  }

  async function manejarAprobar(id) {
    await aprobarTransaccion(id);
    cargar(); // refresca la tabla
  }

  async function manejarRechazar(id) {
    await rechazarTransaccion(id);
    cargar();
  }

  // el resto del componente queda igual, solo usando `transacciones`
  // en vez de `transaccionesMock`, y llamando a manejarAprobar/manejarRechazar
  // en los botones de check/x.
}
```

## 3. Proteger el acceso al panel completo

En tu `App.jsx` (o donde decidas la navegación), envuelve el panel admin así:

```jsx
import { AuthProvider, useAuth } from "./context/AuthContext";
import LoginAdmin from "./LoginAdmin";
import PanelAdmin from "./PanelAdmin";

function RutaAdmin() {
  const { usuario } = useAuth();
  return usuario ? <PanelAdmin /> : <LoginAdmin />;
}

export default function App() {
  return (
    <AuthProvider>
      <RutaAdmin />
    </AuthProvider>
  );
}
```

Así, si no hay sesión iniciada, se muestra el login; si ya inició sesión, se muestra el panel.

## 5. Conectar la página de Inicio a los eventos reales

En `inicio_eventos.jsx`, reemplaza el arreglo `eventos` fijo por:

```jsx
import { useEffect, useState } from "react";
import { obtenerEventos } from "./services/api";

export default function InicioEventos() {
  const [eventos, setEventos] = useState([]);

  useEffect(() => {
    obtenerEventos().then(setEventos).catch(console.error);
  }, []);

  // el resto del componente queda igual: usa `eventos` para el grid
  // y `eventos[0]` (o el que definas como destacado) para el hero
}
```

## 6. Conectar el Checkout a `crearTransaccion`

En `checkout.jsx`, el botón final arma el `FormData` según el método elegido:

```jsx
import { crearTransaccion } from "./services/api";

async function confirmarCompra() {
  const formData = new FormData();
  formData.append("eventoId", evento.id);
  formData.append("correoComprador", correo);
  formData.append("cantidadTickets", cantidad);
  formData.append("metodoPago", metodo === "tarjeta" ? "TARJETA" : "DEPOSITO");

  if (metodo === "deposito") {
    formData.append("comprobante", archivoComprobante); // el File real, no solo el nombre
  } else {
    formData.append("tokenPago", tokenDeLaPasarela); // ver sección de pasarela de pago
  }

  await crearTransaccion(formData);
}
```

Nota: para que esto funcione con la foto real (no solo el nombre), cambia el `onChange`
del input de archivo en el checkout para guardar `e.target.files[0]` en el estado,
en vez de `e.target.files[0]?.name`.

## 4. Crea el archivo `.env` del frontend

En la raíz de tu proyecto de React (no el del backend):

```
VITE_API_URL=http://localhost:4000/api
```
